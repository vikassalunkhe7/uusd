(function ($) {
    $(document).ready(function() {
        $.get( "https://static.stylemixthemes.com/shared/envato-switcher/inline.html").done(function( data ) {
            $('body').append( data );
        });
    });
})(jQuery);